AOS.init({
  duration: 1000,
  once: true,
});

const productList = document.getElementById("productList");
const scrollBtn = document.getElementById("scrollRightBtn");

// Check if the product carousel elements exist on the page
if (productList && scrollBtn) {
  const cardElements = productList.querySelectorAll(".product-card-col");

  const numOriginalCards = 4; // Assuming 4 original cards
  const cardWidth = 320; // Width of a single product card
  // const cardsInView = 3; // Not used in scroll logic
  
  let currentIndex = 0;

 
  
  function scrollProducts() {
    currentIndex++;

    const newScrollPosition = currentIndex * cardWidth;

    productList.scrollTo({
      left: newScrollPosition,
      behavior: "smooth",
    });

    
    if (currentIndex >= numOriginalCards) {
      setTimeout(() => {
        if (currentIndex >= numOriginalCards) {
         
          productList.scrollTo({
            left: 0,
            behavior: "auto",
          });

         
          currentIndex = 0;
          
          
        }
      }, 300); 
    }
  }

 
  scrollBtn.addEventListener("click", scrollProducts);
}
