<?php $__env->startComponent('mail::message'); ?>
# Order Status Updated

Hello <?php echo new \Illuminate\Support\EncodedHtmlString($order->user->name); ?>,

Your order **#<?php echo new \Illuminate\Support\EncodedHtmlString($order->order_number); ?>** status has been updated to:

**<?php echo new \Illuminate\Support\EncodedHtmlString(ucfirst($order->status)); ?>**



Thanks,<br>
<?php echo new \Illuminate\Support\EncodedHtmlString(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\naturolia\resources\views/emails/orders/status_updated.blade.php ENDPATH**/ ?>