


<?php $__env->startSection('content'); ?>

                  <style>
.tracking-timeline {
    border-left: 3px solid #ddd;
    padding-left: 30px;
    margin-left: 20px;
    position: relative;
}

.timeline-step {
    position: relative;
    margin-bottom: 40px;
    padding-left: 20px;
}

.timeline-step::before {
    content: "";
    position: absolute;
    left: -36px;
    top: 4px;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background: #ddd;
    border: 3px solid white;
    z-index: 10;
    transition: background-color 0.3s ease;
}

.timeline-step.completed::before {
    background-color: #28a745; /* Green */
    border-color: #28a745;
}

.timeline-step.active::before {
    background-color: #ffc107; /* Amber */
    border-color: #ffc107;
    box-shadow: 0 0 8px 3px rgba(255, 193, 7, 0.5);
}

.timeline-step::after {
    content: "";
    position: absolute;
    left: -27px;
    top: 26px;
    width: 4px;
    height: 100%;
    background: #ddd;
    z-index: 1;
}

.timeline-step:last-child::after {
    display: none;
}

.timeline-step.completed::after {
    background-color: #28a745;
}

.timeline-step h5 {
    font-weight: 600;
    margin-bottom: 5px;
}

.timeline-step p {
    font-size: 0.85rem;
    color: #666;
    margin: 0;
}
</style>

<section class="py-5 bg-light">
    <div class="container">
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-outline-secondary btn-sm mb-3">
            <i class="fas fa-arrow-left me-2"></i> Back to Orders
        </a>

        <h2 class="mb-4 fw-bold text-dark">Track Your Order</h2>

        <div class="card shadow-sm mb-5">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">Order ID: #<?php echo e(strtoupper($order->order_number)); ?></h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3 mb-3 mb-md-0">
                        <p class="mb-0 small text-uppercase text-muted">Current Status</p>
                        <h4 class="fw-bold 
                            <?php echo e($order->status == 'delivered' ? 'text-success' : 'text-warning'); ?>">
                            <?php echo e(ucfirst($order->status)); ?>

                        </h4>
                    </div>
                    <div class="col-md-3 mb-3 mb-md-0">
                        <p class="mb-0 small text-uppercase text-muted">Tracking ID</p>
                        <h4 class="fw-bold text-dark"><?php echo e($order->tracking_number ?? 'N/A'); ?></h4>
                    </div>
                     <div class="col-md-3 mb-3 mb-md-0">
                        <p class="mb-0 small text-uppercase text-muted">Courier Name</p>
                        <h4 class="fw-bold text-dark"><?php echo e($order->courier_name); ?></h4>
                    </div>
                    <div class="col-md-3">
                        <p class="mb-0 small text-uppercase text-muted">Estimated Delivery</p>
                        <h4 class="fw-bold text-dark">
                            <?php echo e($order->estimated_delivery_date ? \Carbon\Carbon::parse($order->estimated_delivery_date)->format('M d, Y') : 'N/A'); ?>

                        </h4>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-8">
                <div class="card p-4 tracking-status shadow-sm">
                    <h4 class="mb-4"><i class="fas fa-route me-2"></i> Shipment Progress</h4>


<div class="tracking-timeline">
    <?php
        $statuses = ['pending', 'received', 'packed', 'courier', 'out_for_delivery', 'delivered'];
        $currentStatusIndex = array_search($order->status, $statuses);
    ?>

    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="timeline-step 
            <?php if($index < $currentStatusIndex): ?> completed
            <?php elseif($index == $currentStatusIndex): ?> active
            <?php else: ?> pending <?php endif; ?>">
            <h5><?php echo e(ucfirst(str_replace('_', ' ', $status))); ?></h5>
            <?php if($index == $currentStatusIndex): ?>
                <p>Current status</p>
            <?php endif; ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

                </div>
            </div>

            <div class="col-lg-4 mt-4 mt-lg-0">
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-light fw-bold"><i class="fas fa-map-marker-alt me-2"></i> Shipping Address</div>
                    <div class="card-body small">
                        <p class="fw-bold mb-1"><?php echo e($order->user->name); ?> (Home)</p>
                        <address class="mb-0">
                            <?php echo e($order->shipping_address); ?><br>
                            Phone: <?php echo e($order->user->phone ?? 'N/A'); ?>

                        </address>
                    </div>
                </div>

                <div class="card shadow-sm">
                    <div class="card-header bg-light fw-bold"><i class="fas fa-box me-2"></i> Order Items</div>
                    <div class="card-body p-3">
                        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex align-items-center mb-2 border-bottom pb-2">
                                <img src="<?php echo e(asset($item->product->images->first()->image_path ?? 'assets/images/product-placeholder-2.jpg')); ?>"
                                     class="product-image me-3"
                                     style="width: 40px; height: 40px; object-fit: contain;" alt="Item">
                                <div class="small">
                                    <p class="mb-0 fw-bold"><?php echo e($item->product->title ?? 'Product'); ?></p>
                                    <p class="mb-0 text-muted">Qty: <?php echo e($item->quantity); ?> | Total: ₹<?php echo e(number_format($item->price * $item->quantity, 2)); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <p class="fw-bold text-end mb-0 mt-3 small">Order Total: ₹<?php echo e(number_format($order->total, 2)); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\naturolia\resources\views/track-shipment.blade.php ENDPATH**/ ?>