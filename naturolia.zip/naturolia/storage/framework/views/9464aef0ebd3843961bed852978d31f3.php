<!DOCTYPE html>
<html>
<head>
    <title>Courier Details Updated</title>
</head>
<body>
    <h1>Order Courier Details Updated</h1>
    <p>Dear <?php echo e($order->user->name); ?>,</p>
    <p>Your order <strong><?php echo e($order->order_number); ?></strong> has been updated with courier details.</p>
    <ul>
        <li><strong>Courier Name:</strong> <?php echo e($order->courier_name); ?></li>
        <li><strong>Tracking Number:</strong> <?php echo e($order->tracking_number); ?></li>
        <li><strong>Courier Link:</strong> <a href="<?php echo e($order->courier_link); ?>"><?php echo e($order->courier_link); ?></a></li>
    </ul>
    <p>You can track your shipment using the above link.</p>
    <p>Thank you for shopping with us!</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\naturolia\resources\views/emails/courier_details.blade.php ENDPATH**/ ?>