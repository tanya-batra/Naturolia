

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <!-- Display success or error messages -->
        <div class="col-12">
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php elseif($errors->any()): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
        </div>

        <!-- Admin Profile Settings -->
        <div class="col-lg-6">
            <div class="card shadow-lg border-0">
                <div class="card-header bg-primary text-white fw-bold">
                    <i class="bi bi-person-circle"></i> Admin Profile
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.settings.updateProfile')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="mb-4 text-center">
                            <!-- Display Profile Image -->
                            <div class="profile-image">
                                <img src="<?php echo e(asset($admin->profile_image ?? 'default-avatar.png')); ?>" alt="Profile Image" class="rounded-circle" width="120">
                            </div>
                            <div class="mt-2">
                                <label for="profile_image" class="btn btn-info btn-sm">Change Image</label>
                                <input type="file" name="profile_image" id="profile_image" style="display: none;">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" name="name" id="name" value="<?php echo e(old('name', $admin->name)); ?>" class="form-control" required>
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" name="email" id="email" value="<?php echo e(old('email', $admin->email)); ?>" class="form-control" required>
                        </div>

                        <div class="mb-3">
                            <label for="phone" class="form-label">Phone</label>
                            <input type="text" name="phone" id="phone" value="<?php echo e(old('phone', $admin->phone)); ?>" class="form-control">
                        </div>

                        <div class="mb-3">
                            <label for="city" class="form-label">City</label>
                            <input type="text" name="city" id="city" value="<?php echo e(old('city', $admin->city)); ?>" class="form-control">
                        </div>

                        <div class="mb-3">
                            <label for="address" class="form-label">Address</label>
                            <input type="text" name="address" id="address" value="<?php echo e(old('address', $admin->address)); ?>" class="form-control">
                        </div>

                        <div class="mb-3">
                            <label for="zipcode" class="form-label">Zip Code</label>
                            <input type="text" name="zipcode" id="zipcode" value="<?php echo e(old('zipcode', $admin->zipcode)); ?>" class="form-control">
                        </div>

                        <button type="submit" class="btn btn-success">Update Profile</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Change Password Section -->
        <div class="col-lg-6">
            <div class="card shadow-lg border-0">
                <div class="card-header bg-warning text-white fw-bold">
                    <i class="bi bi-lock"></i> Change Password
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.settings.updatePassword')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="current_password" class="form-label">Current Password</label>
                            <input type="password" name="current_password" id="current_password" class="form-control" required>
                        </div>

                        <div class="mb-3">
                            <label for="new_password" class="form-label">New Password</label>
                            <input type="password" name="new_password" id="new_password" class="form-control" required>
                        </div>

                        <div class="mb-3">
                            <label for="new_password_confirmation" class="form-label">Confirm New Password</label>
                            <input type="password" name="new_password_confirmation" id="new_password_confirmation" class="form-control" required>
                        </div>

                        <button type="submit" class="btn btn-warning">Change Password</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\naturolia\resources\views/Admin/admin-profile.blade.php ENDPATH**/ ?>