
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Stats Cards -->
    <div class="row g-4 mb-4">
        <div class="col-md-3">
            <div class="card shadow-lg border-0 h-100">
                <div class="card-body text-center">
                    <div class="mb-3">
                        <i class="bi bi-box-seam fs-1 text-warning"></i>
                    </div>
                    <h6 class="text-muted">Total Product</h6>
                    <h3 class="fw-bold text-dark">320</h3>
                    <small class="text-success"><i class="bi bi-arrow-up"></i> +12 this week</small>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card shadow-lg border-0 h-100">
                <div class="card-body text-center">
                    <div class="mb-3">
                        <i class="bi bi-cart-check fs-1 text-primary"></i>
                    </div>
                    <h6 class="text-muted">Total Orders</h6>
                    <h3 class="fw-bold text-dark">1,245</h3>
                    <small class="text-success"><i class="bi bi-arrow-up"></i> +48 today</small>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card shadow-lg border-0 h-100">
                <div class="card-body text-center">
                    <div class="mb-3">
                        <i class="bi bi-cart-check fs-1 text-primary"></i>
                    </div>
                    <h6 class="text-muted">Pending Orders</h6>
                    <h3 class="fw-bold text-success">$24,560</h3>
                    <small class="text-muted">This month</small>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card shadow-lg border-0 h-100">
                <div class="card-body text-center">
                    <div class="mb-3">
                        <i class="bi bi-people fs-1 text-danger"></i>
                    </div>
                    <h6 class="text-muted">Total Customers</h6>
                    <h3 class="fw-bold text-dark">890</h3>
                    <small class="text-success"><i class="bi bi-person-plus"></i> +25 new</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Sales Overview Chart + Orders -->
  
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('Admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u754765993/domains/buildupnet.com/public_html/naturolia/resources/views/Admin/Dashboard.blade.php ENDPATH**/ ?>