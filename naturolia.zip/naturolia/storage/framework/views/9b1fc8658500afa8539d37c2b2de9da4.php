

<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <h2><?php echo e($product->exists ? 'Edit' : 'Create'); ?> Product</h2>
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e($product->exists ? route('admin.products.update', $product) : route('admin.products.store')); ?>"
            method="POST" enctype="multipart/form-data">

            <?php echo csrf_field(); ?>

            <?php if($product->exists): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>

            <div class="mb-3">
                <label class="form-label">Title</label>
                <input type="text" name="title" value="<?php echo e(old('title', $product->title)); ?>" class="form-control">
            </div>

            <div class="mb-3">
                <label class="form-label">Meta Title</label>
                <input type="text" name="meta_title" value="<?php echo e(old('meta_title', $product->meta_title)); ?>"
                    class="form-control">
            </div>

            <div class="mb-3">
                <label class="form-label">Meta Keywords</label>
                <input type="text" name="meta_keywords" value="<?php echo e(old('meta_keywords', $product->meta_keywords)); ?>"
                    class="form-control">
                <small class="text-muted">Separate with commas</small>
            </div>

            <div class="mb-3">
                <label class="form-label">Slug</label>
                <input type="text" name="slug" value="<?php echo e(old('slug', $product->slug)); ?>" class="form-control">
            </div>

            <div class="mb-3">
                <label class="form-label">Short Description</label>
                <input type="text" name="short_description"
                    value="<?php echo e(old('short_description', $product->short_description)); ?>" class="form-control">
            </div>

            <div class="mb-3">
                <label class="form-label">Key Benefits</label>
              <textarea name="key_benefits" class="form-control" rows="3"><?php echo e(old('key_benefits', $product->key_benefits)); ?></textarea>

            </div>



            <div class="mb-3">
                <label class="form-label">Ingredient</label>
                <textarea name="ingredient" class="form-control" rows="3"><?php echo e(old('ingredient', $product->ingredient)); ?></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea name="description" id="description" class="form-control" rows="15"><?php echo e(old('description', $product->description)); ?></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">Price</label>
                <input type="number" name="price" value="<?php echo e(old('price', $product->price)); ?>" class="form-control"
                    step="0.01">
            </div>

            <div class="mb-3">
                <label class="form-label">Upload Images</label>
                <input type="file" name="images[]" class="form-control" multiple>
                <small class="text-muted">You can select multiple images</small>
            </div>

            
            <?php if($product->exists && $product->images->count()): ?>
                <div class="mb-3">
                    <label class="form-label">Existing Images</label>
                    <div class="row">
                        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3 text-center mb-3">
                                <img src="<?php echo e(asset($image->image_path)); ?>" class="img-fluid rounded mb-1"
                                    style="max-height: 150px;">
                                <form method="POST"
                                    action="<?php echo e(route('admin.products.images.destroy', [$product->id, $image->id])); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger">Delete</button>
                                </form>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>

            <div class="mt-4">
                <button type="submit" class="btn btn-primary"><?php echo e($product->exists ? 'Update' : 'Create'); ?>

                    Product</button>
                <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
    <script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
    <script>
        ClassicEditor
            .create(document.querySelector('#description'))
            .catch(error => {
                console.error(error);
            });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u754765993/domains/buildupnet.com/public_html/naturolia/resources/views/Admin/create-product.blade.php ENDPATH**/ ?>