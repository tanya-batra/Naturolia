

<?php $__env->startSection('content'); ?>
    <section id="home" class="hero-section d-flex align-items-center" data-aos="fade-in">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 text-white" data-aos="fade-right" data-aos-delay="300">
                    <h1 class="display-2 fw-bolder">
                        THE POWER OF NATURE, DELIVERED TO YOU.
                    </h1>
                    <p class="lead fs-5 mb-4">
                        Embrace a healthier life with our carefully sourced organic and
                        natural wellness products.
                    </p>
                    <a href="<?php echo e(route('product')); ?>" class="btn btn-lg custom-btn-primary">Shop Now <i
                            class="fa-solid fa-leaf ms-2"></i></a>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero End -->

    <!-- About Start -->
    <section id="about" class="py-5 bg-white">
        <div class="container py-5">
            <div class="common-header text-center" data-aos="fade-up">
                <h2>Our Story</h2>
                <p class="text-muted">A Commitment to Nature's Healing Wisdom</p>
            </div>
            <div class="row align-items-center mt-5">
                <div class="col-lg-6" data-aos="fade-right">
                    <img src="assets/images/about.jpg" alt="Natural Ingredients" class="img-fluid rounded shadow-lg" />
                </div>
                <div class="col-lg-6 mt-4 mt-lg-0" data-aos="fade-left">
                    <h3 class="fw-bold mb-3 text-green">🌿 About NATUROLIA</h3>
                    <p>
                        NATUROLIA was born with a simple yet powerful vision — to bring
                        people closer to nature’s healing wisdom. We believe true wellness
                        comes from balance — between body, mind, and spirit — and that
                        nature holds the key to restoring it.
                    </p>

                    <p>
                        At NATUROLIA, we combine the timeless knowledge of **Ayurveda with
                        modern scientific research** to create safe, effective, and
                        authentic herbal formulations. Each product is thoughtfully
                        crafted using pure, natural ingredients sourced from trusted
                        cultivators, ensuring potency, purity, and consistency.
                    </p>

                    <p>
                        Our mission is to help individuals embrace a healthier lifestyle
                        through natural, holistic, and sustainable solutions — **free from
                        harmful chemicals and side effects.**
                    </p>

                    <a href="#why-choose" class="btn custom-btn-secondary mt-3">About More</a>
                </div>
            </div>
        </div>
    </section>

    <!-- About End -->

  <!-- Products Start -->
<section id="product" class="py-5 bg-light">
    <div class="container py-5">
        <div class="common-header text-center" data-aos="fade-up">
            <h2>Our Products</h2>
            <p class="text-muted">Nature's Best for Your Daily Health</p>
        </div>

        <div class="product-row-wrapper d-flex align-items-center mt-5 position-relative">
            <div class="row w-100 g-0">
                <div class="col-lg-4 d-none d-lg-block product-fixed-col">
                    <div class="product-banner-fixed shadow-lg" data-aos="fade-right" data-aos-offset="50">
                        <h3 class="text-white fw-bold mb-3">
                            DISCOVER OUR FEATURED COLLECTION
                        </h3>
                        <a href="#product" class="btn btn-lg custom-btn-primary">Explore Now</a>
                    </div>
                </div>

                <div class="col-12 col-lg-8 product-scroll-container position-relative">
                    <div class="product-wrapper">
                        <div class="product-list d-flex flex-nowrap" id="productList">
                         <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="product-card-col">
                <div class="card product-card h-100 shadow-sm">
                    <div class="img-container">
                        <img src="<?php echo e(asset($product->images->isNotEmpty() ? $product->images->first()->image_path : 'images/default-placeholder.jpg')); ?>" alt="<?php echo e($product->title); ?>" class="card-img-top">
                    </div>
                    <div class="card-body text-center">
                        <h5 class="card-title fw-bold">
                            <?php echo e($product->title); ?>

                        </h5>
                        <p class="card-text fs-4 text-green mb-2">₹ <?php echo e(number_format($product->price, 2)); ?></p>

                        <div class="d-flex justify-content-center">
                            <!-- Add to Cart form -->
                            <?php if(auth()->guard()->check()): ?>
                            <form action="<?php echo e(route('cart.add', ['productId' => $product->id])); ?>" method="POST" class="pe-2">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn custom-btn-primary">
                                    <i class="fas fa-shopping-cart me-2"></i>Buy Now
                                </button>
                            </form>
                            <?php else: ?>
                            <!-- If user is not logged in, show the login modal -->
                            <button class="btn custom-btn-primary" data-bs-toggle="modal" data-bs-target="#loginModal">
                                <i class="fas fa-shopping-cart me-2"></i> Buy Now
                            </button>
                            <?php endif; ?>

                            <!-- View Details Button -->
                            <!--<a href="#" class="btn btn-sm custom-btn-secondary ms-2">-->
                            <!--    View Details-->
                            <!--</a>-->
                            
                            <form action="<?php echo e(route('product.show', $product->slug)); ?>" method="GET" class="w-50">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn custom-btn-secondary ms-2">
                                    View Details
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div>
            </div>
            <!-- Scroll next button -->
            <button class="scroll-btn scroll-next d-none d-lg-block" id="scrollRightBtn">
                <i class="fa-solid fa-chevron-right"></i>
            </button>
        </div>
    </div>
</section>
<!-- Products End -->


    <!-- Why Start -->
    <section id="why-choose" class="py-5 bg-light">
        <div class="container py-5">
            <div class="common-header text-center" data-aos="fade-up">
                <h2>Why Choose NATUROLIA?</h2>
                <p class="text-muted">Our Core Principles of Purity and Trust</p>
            </div>
            <div class="row mt-5 justify-content-center" data-aos="fade-up" data-aos-delay="200">
                <div class="col-lg-10 p-4 rounded choose-us-block">
                    <div class="row text-center text-white">
                        <div class="col-md-3 mb-4 mb-md-0">
                            <i class="fa-solid fa-seedling fa-3x mb-3"></i>
                            <p class="small fw-bold">
                                100% Herbal & Ayurvedic formulations
                            </p>
                        </div>
                        <div class="col-md-3 mb-4 mb-md-0">
                            <i class="fa-solid fa-vial fa-3x mb-3"></i>
                            <p class="small fw-bold">
                                Backed by traditional wisdom & modern testing
                            </p>
                        </div>
                        <div class="col-md-3 mb-4 mb-md-0">
                            <i class="fa-solid fa-hand-holding-heart fa-3x mb-3"></i>
                            <p class="small fw-bold">
                                Ethically sourced, cruelty-free ingredients
                            </p>
                        </div>
                        <div class="col-md-3 mb-4 mb-md-0">
                            <i class="fa-solid fa-magnifying-glass-chart fa-3x mb-3"></i>
                            <p class="small fw-bold">
                                Commitment to purity, quality, and transparency
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="text-center mt-5" data-aos="fade-up" data-aos-delay="300">
                <p class="lead mt-4">
                    Whether it’s improving vitality, balancing hormones, or enhancing
                    overall wellness, **NATUROLIA stands for trust, care, and the
                    healing power of nature.**
                </p>
                <p class="display-6 fw-bold text-green mt-4">
                    🌱 NATUROLIA – Inspired by Nature, Perfected by Science.
                </p>
            </div>
        </div>
    </section>
    <!-- Why End -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.3/dist/sweetalert2.min.js"></script>
    <?php if($errors->has('status')): ?>
    <script>
        Swal.fire({
            title: 'Account Inactive',
            text: "<?php echo e($errors->first('status')); ?>",
            icon: 'warning',
            confirmButtonText: 'OK',
        });
    </script>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u754765993/domains/buildupnet.com/public_html/naturolia/resources/views/index.blade.php ENDPATH**/ ?>