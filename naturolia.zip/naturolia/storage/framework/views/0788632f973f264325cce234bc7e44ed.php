

<?php $__env->startSection('content'); ?>
    <section class="profile-section py-5 bg-light">
        <div class="container">
            <h2 class="mb-4 fw-bold text-dark">My Account</h2>

            <div class="row">
                <!-- Sidebar -->
                <div class="col-lg-3 mb-4 mb-lg-0">
                    <div class="list-group profile-sidebar shadow-sm rounded-3 overflow-hidden">
                        <a href="<?php echo e(route('profile.show')); ?>" class="list-group-item list-group-item-action">
                            <i class="fas fa-home me-2"></i> Dashboard
                        </a>
                        <a href="<?php echo e(route('account.orders')); ?>" class="list-group-item list-group-item-action active">
                            <i class="fas fa-box me-2"></i> My Orders
                        </a>
                        <a href="<?php echo e(route('account.address')); ?>" class="list-group-item list-group-item-action">
                            <i class="fas fa-map-marker-alt me-2"></i> My Addresses
                        </a>
                        <a href="<?php echo e(route('account.detail')); ?>" class="list-group-item list-group-item-action">
                            <i class="fas fa-user-edit me-2"></i> Account Details
                        </a>
                        <a href="<?php echo e(route('logout')); ?>" class="list-group-item list-group-item-action text-danger"
                            onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            <i class="fas fa-sign-out-alt me-2"></i> Logout
                        </a>
                    </div>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none"><?php echo csrf_field(); ?></form>
                </div>

                <!-- Orders Section -->
                <div class="col-lg-9">
                    <div class="card shadow-sm">
                        <div class="card-body p-4 p-md-5">
                            <h3 class="card-title mb-4">My Orders History</h3>

                            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="order-card mb-4">
                                    <div class="order-header row g-0 text-muted">
                                        <div class="col-4 text-start">
                                            <p class="mb-0 small text-uppercase">Order Placed</p>
                                            <p class="mb-0 fw-bold text-dark"><?php echo e($order->created_at->format('M d, Y')); ?></p>
                                        </div>
                                        <div class="col-4 text-center">
                                            <p class="mb-0 small text-uppercase">Total</p>
                                            <p class="mb-0 fw-bold text-dark">₹<?php echo e(number_format($order->total, 2)); ?></p>
                                        </div>
                                        <div class="col-4 text-end">
                                            <p class="mb-0 small text-uppercase">Order ID</p>
                                            <p class="mb-0 fw-bold text-primary">#<?php echo e(strtoupper($order->order_number)); ?></p>
                                        </div>
                                    </div>

                                    <div class="order-body mt-3">
                                        
                                        <p
                                            class="status-line mb-3 
                                        <?php echo e($order->status == 'delivered'
                                            ? 'text-success'
                                            : ($order->status == 'shipped'
                                                ? 'text-warning'
                                                : 'text-secondary')); ?>">
                                            <i class="fas fa-box-open me-2"></i>
                                            <?php echo e(ucfirst($order->status)); ?>

                                            <?php if($order->delivered_at): ?>
                                                on <?php echo e(\Carbon\Carbon::parse($order->delivered_at)->format('M d, Y')); ?>

                                            <?php endif; ?>
                                        </p>

                                        
                                        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="order-product-item d-flex align-items-center mb-3">
                                                <img src="<?php echo e($item->product->images->first()->image_path
                                                    ? asset($item->product->images->first()->image_path)
                                                    : asset('assets/images/product-placeholder-1.jpg')); ?>"
                                                    class="product-image me-3" width="60" height="60"
                                                    alt="<?php echo e($item->product->name); ?>">
                                                <div>
                                                    <p class="mb-1 fw-bold"><?php echo e($item->product->title ?? 'Product'); ?></p>
                                                    <p class="mb-0 small text-muted">
                                                        Quantity: <?php echo e($item->quantity); ?> |
                                                        Price: ₹<?php echo e(number_format($item->price, 2)); ?>

                                                    </p>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <div class="mt-4 pt-3 border-top">

                                          
                                            <?php if($order->invoice_path): ?>
                                                <a href="<?php echo e(asset($order->invoice_path)); ?>" target="_blank"
                                                    class="btn btn-sm btn-outline-primary me-2">
                                                    <i class="fas fa-receipt me-1"></i> View Invoice
                                                </a>
                                            <?php else: ?>
                                                <span class="text-muted me-2">No Invoice</span>
                                            <?php endif; ?>

                                        
                                            <?php if(in_array($order->status, ['shipped', 'courier', 'delivered'])): ?>
                                                <a href="<?php echo e(route('orders.track', $order->id)); ?>"
                                                    class="btn btn-sm btn-primary me-2">
                                                    <i class="fas fa-truck me-1"></i> Track Shipment
                                                </a>
                                            <?php endif; ?>

                                          
                                            <?php if($order->status === 'delivered'): ?>
                                                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a href="<?php echo e(route('reviews.create', ['product' => $item->product->id, 'order' => $order->id])); ?>"
                                                        class="btn btn-sm btn-outline-secondary me-2 mb-2 d-inline-block">
                                                        <i class="fas fa-star me-1"></i> Write Review for
                                                        <?php echo e(Str::limit($item->product->title, 20)); ?>

                                                    </a>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>

                                        </div>


                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="alert alert-info">
                                    <i class="fas fa-info-circle me-2"></i> You haven't placed any orders yet.
                                </div>
                            <?php endif; ?>

                            <div class="mt-4 d-flex justify-content-center">
                                <?php echo e($orders->links('pagination::bootstrap-5')); ?>

                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\naturolia\resources\views/profile-orders.blade.php ENDPATH**/ ?>