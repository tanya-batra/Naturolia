

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Stats Cards -->
    <div class="col-lg-12">
        <div class="card shadow-lg border-0">
            <div class="card-header bg-dark text-white fw-bold">
                Admin List
            </div>
            <div class="card-body p-0">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>S No .</th>
                            <th>Profile</th>
                            <th>Name</th>
                            <th>Mobile No</th>
                            <th>Email ID</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td>
                                  
                                    <?php if($admin->profile_image): ?>
                                        <img src="<?php echo e(asset('storage/' . $admin->profile_image)); ?>" alt="Profile Image" width="50" height="50" class="rounded-circle">
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($admin->name); ?></td>
                                <td><?php echo e($admin->phone ?? 'N/A'); ?></td>
                                <td><?php echo e($admin->email); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u754765993/domains/buildupnet.com/public_html/naturolia/resources/views/Admin/admins.blade.php ENDPATH**/ ?>