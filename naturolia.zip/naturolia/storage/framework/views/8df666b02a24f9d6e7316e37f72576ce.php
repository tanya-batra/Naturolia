<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Login</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        body {
            color: black;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial,
                "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
        }

        .form-container {
            background-color: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            margin: 80px auto;
        }

        .form-control {
            padding-left: 40px;
            border-radius: 50px;
        }

        .input-group-custom {
            position: relative;
            margin-bottom: 1.5rem;
        }

        .input-icon {
            position: absolute;
            top: 50%;
            left: 15px;
            transform: translateY(-50%);
            color: #6c757d;
        }

        .password-wrapper {
            position: relative;
        }

        .toggle-password {
            position: absolute;
            top: 50%;
            right: 12px;
            transform: translateY(-50%);
            cursor: pointer;
            color: #6c757d;
        }

        .btn-custom {
            background-color: #b7472a;
            color: white;
            font-weight: bold;
            border-radius: 50px;
        }

        .btn-custom:hover {
            background-color: #a43f26;
        }

        .register-link {
            text-align: center;
            margin-top: 20px;
            font-size: 0.95em;
        }

        .register-link a {
            color: #b7472a;
            text-decoration: none;
            font-weight: bold;
        }

        .register-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>

    <div class="container">
        <div class="form-container">
            <h3 class="text-center mb-4">Login</h3>

            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>

                <div class="input-group-custom">
                    <i class="bi bi-envelope input-icon"></i>
                    <input type="email" name="email" class="form-control" placeholder="Email Address"
                        value="<?php echo e(old('email')); ?>" required autofocus>
                </div>

                <div class="input-group-custom password-wrapper">
                    <i class="bi bi-lock input-icon"></i>
                    <input type="password" name="password" class="form-control" placeholder="Password" id="password"
                        required>
                    <i class="bi bi-eye-slash toggle-password" id="togglePassword"></i>
                </div>
                <div class="text-end mb-3">
                    <a href="" class="text-decoration-none  text-muted"
                        style="font-size: 0.9em;">
                        Forgot Password?
                    </a>
                </div>
                <div class="d-grid">
                    <button type="submit" class="btn btn-custom">Login</button>
                </div>

                <div class="register-link">
                    Don't have an account? <a href="<?php echo e(route('register')); ?>">Register here</a>
                </div>
            </form>
        </div>
    </div>

    <?php if($errors->any()): ?>
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Login Failed',
                    html: `<?php echo implode('<br>', $errors->all()); ?>`,
                    confirmButtonColor: '#b7472a'
                });
            });
        </script>
    <?php endif; ?>

    <script>
        const togglePassword = document.getElementById('togglePassword');
        const passwordInput = document.getElementById('password');

        togglePassword.addEventListener('click', function() {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.classList.toggle('bi-eye');
            this.classList.toggle('bi-eye-slash');
        });
    </script>

</body>

</html>
<?php /**PATH /home/u754765993/domains/buildupnet.com/public_html/naturolia/resources/views/Auth/login.blade.php ENDPATH**/ ?>