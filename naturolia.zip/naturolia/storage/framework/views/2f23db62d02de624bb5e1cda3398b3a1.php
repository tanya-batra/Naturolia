

<?php $__env->startSection('content'); ?>
    <!--<div class="container py-5">-->
    <!--    <div class="row">-->
    <!--        <div class="col-md-8 mx-auto">-->
    <!--            <div class="card shadow-sm">-->
    <!--                <div class="card-header">-->
    <!--                    <h5 class="mb-0">My Profile</h5>-->
    <!--                </div>-->
    <!--                <div class="card-body">-->
    <!--                    -->
    <!--                    <?php if(session('success')): ?>-->
    <!--                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>-->
    <!--                    <?php endif; ?>-->

    <!--                    -->
    <!--                    <form action="<?php echo e(route('profile.update')); ?>" method="POST">-->
    <!--                        <?php echo csrf_field(); ?>-->
    <!--                        <?php echo method_field('PUT'); ?>-->

    <!--                        <div class="mb-3">-->
    <!--                            <label for="name" class="form-label">Name</label>-->
    <!--                            <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name', $user->name)); ?>" required>-->
    <!--                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>-->
    <!--                        </div>-->

    <!--                        <div class="mb-3">-->
    <!--                            <label for="email" class="form-label">Email</label>-->
    <!--                            <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email', $user->email)); ?>" required>-->
    <!--                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>-->
    <!--                        </div>-->

    <!--                        <div class="mb-3">-->
    <!--                            <label for="phone" class="form-label">Phone</label>-->
    <!--                            <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e(old('phone', $user->phone)); ?>">-->
    <!--                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>-->
    <!--                        </div>-->

    <!--                        <h6>Shipping Address</h6>-->

    <!--                        <div class="mb-3">-->
    <!--                            <label for="address" class="form-label">Address</label>-->
    <!--                            <input type="text" class="form-control" id="address" name="address" value="<?php echo e(old('address', $user->address)); ?>">-->
    <!--                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>-->
    <!--                        </div>-->

    <!--                        <div class="mb-3">-->
    <!--                            <label for="city" class="form-label">City</label>-->
    <!--                            <input type="text" class="form-control" id="city" name="city" value="<?php echo e(old('city', $user->city)); ?>">-->
    <!--                        </div>-->

    <!--                        <div class="mb-3">-->
    <!--                            <label for="zipcode" class="form-label">Zipcode</label>-->
    <!--                            <input type="text" class="form-control" id="zipcode" name="zipcode" value="<?php echo e(old('zipcode', $user->zipcode)); ?>">-->
    <!--                        </div>-->

    <!--                        <button type="submit" class="btn btn-primary">Update Profile</button>-->
    <!--                    </form>-->

    <!--                    <hr>-->

    <!--                    -->
    <!--                    <h5>Change Profile Image</h5>-->
    <!--                    <form action="<?php echo e(route('profile.image')); ?>" method="POST" enctype="multipart/form-data">-->
    <!--                        <?php echo csrf_field(); ?>-->

    <!--                        -->
    <!--                        <?php if($user->profile_image): ?>-->
    <!--                            <img src="<?php echo e(asset('storage/' . $user->profile_image)); ?>" alt="Profile Image" class="img-thumbnail" width="150">-->
    <!--                        <?php else: ?>-->
    <!--                            <img src="<?php echo e(asset('storage/default-avatar.png')); ?>" alt="Profile Image" class="img-thumbnail" width="150">-->
    <!--                        <?php endif; ?>-->
                            
    <!--                        <div class="mb-3 mt-3">-->
    <!--                            <label for="profile_image" class="form-label">Upload New Profile Image</label>-->
    <!--                            <input type="file" class="form-control" id="profile_image" name="profile_image" accept="image/*">-->
    <!--                            <?php $__errorArgs = ['profile_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>-->
    <!--                        </div>-->

    <!--                        <button type="submit" class="btn btn-primary">Change Profile Image</button>-->
    <!--                    </form>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    
        <section class="profile-section py-5 bg-light">
        <div class="container">
            <h2 class="mb-4 fw-bold text-dark">My Account</h2>

            <div class="row">
                <div class="col-12 d-lg-none mb-3">
                    <button class="btn btn-outline-secondary w-100" type="button" data-bs-toggle="collapse"
                        data-bs-target="#profileSidebarCollapse">
                        <i class="fas fa-bars me-2"></i> Profile Menu
                    </button>
                </div>

                <div class="col-lg-3 mb-4 mb-lg-0">
                    <div class="collapse d-lg-block" id="profileSidebarCollapse">
                        <div class="list-group profile-sidebar shadow-sm rounded-3 overflow-hidden">
    <a href="<?php echo e(route('profile.show')); ?>" class="list-group-item list-group-item-action <?php echo e(request()->routeIs('account.dashboard') ? 'active' : ''); ?>">
        <i class="fas fa-home me-2"></i> Dashboard
    </a>

    <a href="<?php echo e(route('account.orders')); ?>" class="list-group-item list-group-item-action <?php echo e(request()->routeIs('account.orders') ? 'active' : ''); ?>">
        <i class="fas fa-box me-2"></i> My Orders
    </a>

    <a href="<?php echo e(route('account.address')); ?>" class="list-group-item list-group-item-action <?php echo e(request()->routeIs('account.address') ? 'active' : ''); ?>">
        <i class="fas fa-map-marker-alt me-2"></i> My Addresses
    </a>

    <a href="<?php echo e(route('account.detail')); ?>" class="list-group-item list-group-item-action <?php echo e(request()->routeIs('account.detail') ? 'active' : ''); ?>">
        <i class="fas fa-user-edit me-2"></i> Account Details
    </a>

    <a href="<?php echo e(route('logout')); ?>" class="list-group-item list-group-item-action text-danger"
        onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
        <i class="fas fa-sign-out-alt me-2"></i> Logout
    </a>
</div>

<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
    <?php echo csrf_field(); ?>
</form>

                    </div>
                </div>

                <div class="col-lg-9">
                    <div class="card profile-content-card shadow-sm h-100">
                        <div class="card-body p-4 p-md-5">

                            <h3 class="card-title mb-4">Welcome Back,  <?php echo e($user->name); ?>!</h3>

                          <?php if($profileCompletion >= 80): ?>
    <div class="alert alert-success d-flex align-items-center" role="alert">
        <i class="fas fa-check-circle me-2"></i>
        Your profile is complete! Start exploring our new collection.
    </div>
<?php else: ?>
    <div class="alert alert-warning d-flex align-items-center" role="alert">
        <i class="fas fa-exclamation-circle me-2"></i>
        Please complete your profile first — add your phone number and address.
    </div>
<?php endif; ?>

                            <div class="row g-4 mb-5">
                                <div class="col-lg-4 col-md-6">
                                    <div class="p-4 border rounded text-center bg-white shadow-sm quick-stat-box">
                                        <i class="fas fa-box fa-3x text-primary mb-2"></i>
                                        <h5 class="mt-2 text-muted small">Pending Orders</h5>
                                        <p class="display-6 fw-bold text-dark"><?php echo e($pendingOrderCount); ?></p>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-6">
                                    <div class="p-4 border rounded text-center bg-white shadow-sm quick-stat-box">
                                        <i class="fas fa-map-marker-alt fa-3x text-success mb-2"></i>
                                        <h5 class="mt-2 text-muted small">Saved Addresses</h5>
                                        <p class="display-6 fw-bold text-dark"><?php echo e($totalAddressCount); ?></p>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-12">
                                    <div class="p-4 border rounded text-center bg-white shadow-sm quick-stat-box">
                                       <i class="fas fa-shopping-cart fa-3x text-danger mb-2"></i>

                                        <h5 class="mt-2 text-muted small">Total Order</h5>
                                        <p class="display-6 fw-bold text-dark"><?php echo e($orderCount); ?></p>
                                    </div>
                                </div>
                            </div>

                          <h4 class="mb-3 border-bottom pb-2">Recent Order Summary</h4>

<?php if($recentOrder): ?>
    <div class="p-4 border rounded bg-white">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <p class="fw-bold mb-0">Order ID: 
                <span class="text-primary">#<?php echo e($recentOrder->order_number); ?></span>
            </p>
            <span class="badge bg-warning text-dark py-2"><?php echo e(ucfirst($recentOrder->status)); ?></span>
        </div>
        <p class="mb-1">Date: <?php echo e($recentOrder->created_at->format('Y-m-d')); ?></p>
        <p class="mb-3">Total: ₹<?php echo e(number_format($recentOrder->total, 2)); ?> (<?php echo e($recentOrder->items()->count()); ?> Item<?php echo e($recentOrder->items()->count() > 1 ? 's' : ''); ?>)</p>
        <a href="<?php echo e(route('account.orders')); ?>" class="btn btn-sm btn-outline-primary">View Full History</a>
    </div>
<?php else: ?>
    <p>No recent orders found.</p>
<?php endif; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u754765993/domains/buildupnet.com/public_html/naturolia/resources/views/user-profile.blade.php ENDPATH**/ ?>