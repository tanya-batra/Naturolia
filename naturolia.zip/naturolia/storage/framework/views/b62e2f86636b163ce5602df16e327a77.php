

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="col-lg-12">
            <div class="card shadow-lg border-0">
                <div class="card-header bg-dark text-white fw-bold">
                    Pending Order List
                </div>
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <div class="card-body p-0">
                    <div class="accordion" id="accordionOrders">
                        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading<?php echo e($order->id); ?>">
                                    <button class="accordion-button collapsed border-0 bg-light" type="button"
                                        data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($order->id); ?>"
                                        aria-expanded="false" aria-controls="collapse<?php echo e($order->id); ?>">
                                        <table class="table align-middle mb-0">
                                            <thead class="table-light">
                                                <tr>
                                                    <th>Order ID</th>
                                                    <th>Status</th>
                                                    <th>Change Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td><?php echo e($order->order_number); ?></td>
                                                    <td><span
                                                            class="badge bg-info text-dark"><?php echo e(ucfirst($order->status)); ?></span>
                                                    </td>
                                                    <td>
                                                        <form action="<?php echo e(route('admin.orders.status', $order->id)); ?>"
                                                            method="POST" class="d-flex gap-2"
                                                            id="status-form-<?php echo e($order->id); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PATCH'); ?>
                                                            <select name="status"
                                                                class="form-select form-select-sm status-select"
                                                                data-order-id="<?php echo e($order->id); ?>" required>
                                                                <option value="pending"
                                                                    <?php echo e($order->status == 'pending' ? 'selected' : ''); ?>>
                                                                    Pending</option>
                                                                <option value="received"
                                                                    <?php echo e($order->status == 'received' ? 'selected' : ''); ?>>
                                                                    Order Received</option>
                                                                <option value="packed"
                                                                    <?php echo e($order->status == 'packed' ? 'selected' : ''); ?>>
                                                                    Order Packed</option>
                                                                <option value="courier"
                                                                    <?php echo e($order->status == 'courier' ? 'selected' : ''); ?>

                                                                    <?php echo e(!$order->courier_name ? 'disabled' : ''); ?>>
                                                                    Courier</option>
                                                                <option value="delivered"
                                                                    <?php echo e($order->status == 'delivered' ? 'selected' : ''); ?>>
                                                                    Delivered</option>
                                                                <option value="cancelled"
                                                                    <?php echo e($order->status == 'cancelled' ? 'selected' : ''); ?>>
                                                                    Cancelled</option>
                                                            </select>

                                                            <button type="submit"
                                                                class="btn btn-sm btn-primary">Update</button>

                                                            <button type="button" class="btn btn-sm btn-secondary"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#courierModal<?php echo e($order->id); ?>">
                                                                Courier Details
                                                            </button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </button>
                                </h2>

                                <div class="modal fade" id="courierModal<?php echo e($order->id); ?>" tabindex="-1"
                                    aria-labelledby="courierModalLabel<?php echo e($order->id); ?>" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <form action="<?php echo e(route('admin.orders.courier-details', $order->id)); ?>"
                                            method="POST" class="modal-content">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="courierModalLabel<?php echo e($order->id); ?>">Add
                                                    Courier Details</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label for="courier_name_<?php echo e($order->id); ?>"
                                                        class="form-label">Courier Name</label>
                                                    <input type="text" name="courier_name"
                                                        id="courier_name_<?php echo e($order->id); ?>" class="form-control"
                                                        required>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="tracking_number_<?php echo e($order->id); ?>"
                                                        class="form-label">Tracking Number</label>
                                                    <input type="text" name="tracking_number"
                                                        id="tracking_number_<?php echo e($order->id); ?>" class="form-control"
                                                        required>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="courier_link_<?php echo e($order->id); ?>"
                                                        class="form-label">Courier Link</label>
                                                    <input type="url" name="courier_link"
                                                        id="courier_link_<?php echo e($order->id); ?>" class="form-control"
                                                        placeholder="https://tracking-url.com/your-tracking-code" required>
                                                </div>


                                            </div>
                                            <div class="modal-footer">
                                                <button type="submit" class="btn btn-primary">Save Details</button>
                                                <button type="button" class="btn btn-secondary"
                                                    data-bs-dismiss="modal">Close</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <div id="collapse<?php echo e($order->id); ?>" class="accordion-collapse collapse"
                                    aria-labelledby="heading<?php echo e($order->id); ?>" data-bs-parent="#accordionOrders">
                                    <div class="accordion-body">
                                        <div class="table-responsive">
                                            <table class="table table-hover align-middle mb-0">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>Product Name</th>
                                                        <th>Product Image</th>
                                                        <th>Quantity</th>
                                                        <th>User City</th>
                                                        <th>Shipping Address</th>
                                                        <th>Zip Code</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($item->product->title ?? 'N/A'); ?></td>
                                                            <td>
                                                                <img src="<?php echo e(asset($item->product->images->first()->image_path ?? 'images/default-placeholder.jpg')); ?>"
                                                                    alt="Product Image" width="50" height="50"
                                                                    class="rounded">
                                                            </td>
                                                            <td><?php echo e($item->quantity); ?></td>
                                                            <td><?php echo e($order->user->city ?? 'N/A'); ?></td>
                                                            <td><?php echo e($order->shipping_address); ?></td>
                                                            <td><?php echo e($order->user->zipcode ?? 'N/A'); ?></td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-center p-4">No pending orders found.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.querySelectorAll('.status-select').forEach(select => {
            select.addEventListener('change', function() {
                const selected = this.value;
                const orderId = this.dataset.orderId;

                // If user tries to select 'courier' but courier details are missing, prevent submission
                if (selected === 'courier' && this.querySelector('option[value="courier"]').disabled) {
                    alert('Please add courier details before changing status to courier.');
                    // Reset select to previous value
                    this.value = <?php echo json_encode(old('status', 'pending'), 512) ?>; // Or store previous value if needed
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\naturolia\resources\views/Admin/pending-order.blade.php ENDPATH**/ ?>