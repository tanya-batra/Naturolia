

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Completed Orders List -->
    <div class="col-lg-12">
        <div class="card shadow-lg border-0">
            <div class="card-header bg-dark text-white fw-bold">
                Completed Orders List
            </div>
            <div class="card-body p-0">
                <div class="accordion" id="accordionCompletedOrders">
                    <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="heading<?php echo e($order->id); ?>">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($order->id); ?>" aria-expanded="false" aria-controls="collapse<?php echo e($order->id); ?>">
                                <table class="table table-hover align-middle mb-0 mb-0 w-100">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Order ID</th>
                                            <th>Status</th>
                                            <th>Order Date</th>
                                            <th>Total Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><?php echo e($order->order_number); ?></td>
                                            <td><span class="badge bg-success"><?php echo e(ucfirst($order->status)); ?></span></td>
                                            <td><?php echo e($order->created_at->format('d M, Y')); ?></td>
                                            <td>₹ <?php echo e(number_format($order->total, 2)); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </button>
                        </h2>
                        <div id="collapse<?php echo e($order->id); ?>" class="accordion-collapse collapse" aria-labelledby="heading<?php echo e($order->id); ?>" data-bs-parent="#accordionCompletedOrders">
                            <div class="accordion-body">
                                <div class="table-responsive">
                                    <table class="table table-hover align-middle mb-0">
                                        <thead class="table-light">
                                            <tr>
                                                <th>Product Name</th>
                                                <th>Product Image</th>
                                                <th>Quantity</th>
                                                <th>User City</th>
                                                <th>Shipping Address</th>
                                                <th>Zip Code</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($item->product->title ?? 'N/A'); ?></td>
                                                <td>
                                                    <img src="<?php echo e(asset($item->product->images->first()->image_path ?? 'images/default-placeholder.jpg')); ?>" alt="Product Image" width="50" height="50" class="rounded">
                                                </td>
                                                <td><?php echo e($item->quantity); ?></td>
                                                <td><?php echo e($order->user->city ?? 'N/A'); ?></td>
                                                <td><?php echo e($order->shipping_address); ?></td>
                                                <td><?php echo e($order->user->zipcode ?? 'N/A'); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-center p-4">No completed orders found.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\naturolia\resources\views/Admin/completed-order.blade.php ENDPATH**/ ?>