

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Stats Cards -->
    <div class="col-lg-12">
        <div class="card shadow-lg border-0">
            <div class="card-header bg-dark text-white fw-bold">
                Pending Order List
            </div>
            <div class="card-body p-0">
                <div class="accordion" id="accordionExample">
                    <!-- Start of each Order Accordion Item -->
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingorderid ">
                            <button class="accordion-button border-0 bg-light" type="button" data-bs-toggle="collapse" data-bs-target="#collapseorderid " aria-expanded="true" aria-controls="collapseorderid">
                               <table class="table align-middle mb-0">
                                        <thead class="table-light">
                                            <tr>
                                                <th>Order ID</th>
                                                <th>Status</th>
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <!-- Loop through products in each order -->
                                            <tr>
                                                <td>productIndex + 1 </td>
                                                <td>
                                                    <button class="btn btn-sm btn-primary">Order Recived</button>
                                                    <button class="btn btn-sm btn-primary">Order Packed</button>
                                                    <button class="btn btn-sm btn-primary">Curior</button>
                                                    
                                                </td>
                                            </tr>
                                            <!-- Repeat the product row for each product in the order -->
                                        </tbody>
                                    </table>

                            </button>
                        </h2>
                        <div id="collapseorderid" class="accordion-collapse collapse" aria-labelledby="headingorder.=id" data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <!-- Display Order Details -->
                                <div class="table-responsive">
                                    <table class="table table-hover align-middle mb-0">
                                        <thead class="table-light">
                                            <tr>
                                                <th>Product Name</th>
                                                <th>Product Img</th>
                                                <th>Qty</th>
                                                <th>City</th>
                                                <th>Address</th>
                                                <th>Zip Code</th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <!-- Loop through products in each order -->
                                            <tr>
                                                <td>productIndex + 1 </td>
                                                <td>
                                                    <!-- Display profile image if available -->
                                                    <img src="" alt="Profile Image" width="50" height="50" class="rounded-circle">
                                                </td>
                                                <td>product.admin.name </td>
                                                <td>product.admin.phone 'N/A'</td>
                                                <td>product.admin.email</td>
                                            </tr>
                                            <!-- Repeat the product row for each product in the order -->
                                        </tbody>
                                    </table>
                                </div>
                                
                                
                            </div>
                        </div>
                    </div>
                    
                   
                    <!-- End of each Order Accordion Item -->
                </div>
            </div>
            
            
                   <div class="card-body p-0">
                <div class="accordion" id="accordionExample1">
                    <!-- Start of each Order Accordion Item -->
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingorderid ">
                            <button class="accordion-button border-0 bg-light" type="button" data-bs-toggle="collapse" data-bs-target="#collapseorderid1 " aria-expanded="true" aria-controls="collapseorderid1">
                               <table class="table align-middle mb-0">
                                        <thead class="table-light">
                                            <tr>
                                                <th>Order ID</th>
                                                <th>Status</th>
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <!-- Loop through products in each order -->
                                            <tr>
                                                <td>productIndex + 1 </td>
                                                <td>
                                                    <button class="btn btn-sm btn-primary">Order Recived</button>
                                                    <button class="btn btn-sm btn-primary">Order Packed</button>
                                                    <button class="btn btn-sm btn-primary">Curior</button>
                                                    
                                                </td>
                                            </tr>
                                            <!-- Repeat the product row for each product in the order -->
                                        </tbody>
                                    </table>

                            </button>
                        </h2>
                        <div id="collapseorderid1" class="accordion-collapse collapse" aria-labelledby="headingorder.=id" data-bs-parent="#accordionExample1">
                            <div class="accordion-body">
                                <!-- Display Order Details -->
                                <div class="table-responsive">
                                    <table class="table table-hover align-middle mb-0">
                                        <thead class="table-light">
                                            <tr>
                                                <th>Product Name</th>
                                                <th>Product Img</th>
                                                <th>Qty</th>
                                                <th>City</th>
                                                <th>Address</th>
                                                <th>Zip Code</th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <!-- Loop through products in each order -->
                                            <tr>
                                                <td>productIndex + 1 </td>
                                                <td>
                                                    <!-- Display profile image if available -->
                                                    <img src="" alt="Profile Image" width="50" height="50" class="rounded-circle">
                                                </td>
                                                <td>product.admin.name </td>
                                                <td>product.admin.phone 'N/A'</td>
                                                <td>product.admin.email</td>
                                            </tr>
                                            <!-- Repeat the product row for each product in the order -->
                                        </tbody>
                                    </table>
                                </div>
                                
                                
                            </div>
                        </div>
                    </div>
                    
                   
                    <!-- End of each Order Accordion Item -->
                </div>
            </div>
            
            
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<H1>HELLO</H1>
<?php echo $__env->make('Admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u754765993/domains/buildupnet.com/public_html/naturolia/resources/views/Admin/pending-order.blade.php ENDPATH**/ ?>