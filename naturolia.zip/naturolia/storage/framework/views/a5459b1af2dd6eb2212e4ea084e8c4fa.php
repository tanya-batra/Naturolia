

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h2 class="mb-4">All Orders</h2>

    <?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered table-hover align-middle">
        <thead class="table-light">
            <tr>
                <th>Order Number</th>
                <th>User</th>
                <th>Status</th>
                <th>Total</th>
                <th>Invoice</th>
                <th>Shipment</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($order->order_number); ?></td>
                <td><?php echo e($order->user->name ?? 'N/A'); ?></td>
                <td>
                    <span class="badge bg-info text-dark"><?php echo e(ucfirst($order->status)); ?></span>
                </td>
                <td>$<?php echo e(number_format($order->total, 2)); ?></td>
                <td>
                    <?php if($order->invoice_path): ?>
                        <a href="<?php echo e(asset($order->invoice_path)); ?>" target="_blank" class="btn btn-sm btn-primary">View Invoice</a>
                        <a href="<?php echo e(asset($order->invoice_path)); ?>" download class="btn btn-sm btn-secondary">Download Invoice</a>
                    <?php else: ?>
                        <span class="text-muted">No Invoice</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if($order->tracking_number && $order->courier_link): ?>
                        <a href="<?php echo e($order->courier_link); ?>" target="_blank" class="btn btn-sm btn-success">Track Shipment</a>
                    <?php else: ?>
                        <span class="text-muted">No Tracking Info</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" class="text-center">No orders found.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\naturolia\resources\views/Admin/all-order.blade.php ENDPATH**/ ?>