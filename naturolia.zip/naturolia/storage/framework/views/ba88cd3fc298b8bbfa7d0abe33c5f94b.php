<?php $__env->startComponent('mail::message'); ?>
# Thank you for your order, <?php echo new \Illuminate\Support\EncodedHtmlString($order->user->name); ?>!

Your order **#<?php echo new \Illuminate\Support\EncodedHtmlString($order->order_number); ?>** has been placed successfully.

**Order Total:** ₹<?php echo new \Illuminate\Support\EncodedHtmlString(number_format($order->total, 2)); ?>


We’ve attached your invoice PDF to this email.

Thanks,<br>
<?php echo new \Illuminate\Support\EncodedHtmlString(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\naturolia\resources\views/emails/invoice.blade.php ENDPATH**/ ?>