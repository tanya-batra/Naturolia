<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\Mail;
use App\Mail\OtpMail;

class ForgotPasswordController extends Controller
{
    // Send OTP
    public function sendOtp(Request $request)
    {
        $request->validate([
            'email' => 'required|email|exists:users,email',
        ]);

        $user = User::where('email', $request->email)->first();

        // Generate a 6-digit OTP
        $otp = rand(100000, 999999);

        // Store OTP and expiration time in the user's record
        $user->otp = $otp;
        $user->otp_expires_at = Carbon::now()->addMinutes(10); // OTP valid for 10 minutes
        $user->save();

        // Send OTP to user's email
        Mail::to($user->email)->send(new OtpMail($otp));

        // Return a response indicating OTP was sent
        return response()->json([
            'success' => true,
            'otp_verified' => false, // We are still in the OTP sending phase
            'message' => 'OTP sent to your email.',
        ]);
    }

    // Verify OTP
    public function verifyOtp(Request $request)
    {
        $request->validate([
            'otp' => 'required|numeric|digits:6',
            'email' => 'required|email', // Added validation for email
        ]);

        // Retrieve the user by email
        $user = User::where('email', $request->email)->first();

        // Check if OTP matches and is valid
        if ($user && $user->otp == $request->otp && Carbon::now()->lt($user->otp_expires_at)) {
            return response()->json([
                'success' => true,
                'otp_verified' => true,
                'message' => 'OTP verified successfully.',
            ]);
        } else {
            return response()->json([
                'success' => false,
                'otp_verified' => false,
                'message' => 'Invalid OTP or OTP expired.',
            ]);
        }
    }

    // Show reset password form
    public function showResetPasswordForm()
    {
        return view('auth.reset-password');
    }

    // Handle resetting the password
    public function resetPassword(Request $request)
    {
        $request->validate([
            'password' => 'required|confirmed|min:8',
        ]);

        $user = User::where('email', session('email'))->first();

        if (!$user) {
            return redirect()->route('password.request')->withErrors(['email' => 'No user found with this email.']);
        }

        // Update password
        $user->password = bcrypt($request->password);
        $user->otp = null; // Clear OTP after reset
        $user->otp_expires_at = null; // Clear expiration time
        $user->save();

        // Return to login page after password reset
        return redirect()->route('login')->with('success', 'Password has been reset successfully.');
    }
}
