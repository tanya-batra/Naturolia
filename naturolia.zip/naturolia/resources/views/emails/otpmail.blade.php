<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your OTP for Password Reset</title>
</head>
<body>
    <h1>Your OTP Code</h1>
    <p>Here is your OTP code for resetting your password: <strong>{{ $otp }}</strong></p>
    <p>This OTP will expire in 10 minutes.</p>
</body>
</html>
