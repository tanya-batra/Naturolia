@extends('Admin.layout.app')

@section('content')
<div class="container py-4">
    <h2 class="mb-4">All Products</h2>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle text-center">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Slug</th>
                    <th>Short Description</th>
                    <th>Price (₹)</th>
                    <th>Images</th>
                    <th>Best Product</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($products as $index => $product)
                    <tr>
                        <td>{{ $index + 1 }}</td>
                        <td>{{ $product->title }}</td>
                        <td>{{ $product->slug }}</td>
                        <td>{{ \Illuminate\Support\Str::limit($product->short_description, 50) }}</td>
                        <td>{{ number_format($product->price, 2) }}</td>
                        <td>
                            @if($product->images->count())
                                <img src="{{ asset($product->images->first()->image_path) }}" alt="Product Image" width="60" class="img-thumbnail">
                            @else
                                <span class="text-muted">No Image</span>
                            @endif
                        </td>
                        <td>
                            <!-- Best Product Toggle Button -->
                            <button class="btn btn-sm toggle-best-product {{ $product->best_product ? 'btn-success' : 'btn-secondary' }}" 
                                    data-id="{{ $product->id }}">
                                {{ $product->best_product ? 'Best Product' : 'Mark as Best' }}
                            </button>
                        </td>
                        <td>
                            <a href="{{ route('admin.products.edit', $product->id) }}" class="btn btn-sm btn-primary mb-2">
                                <i class="bi bi-pencil-square"></i>
                            </a>

                            <form action="{{ route('admin.products.destroy', $product->id) }}" method="POST" class="d-inline"
                                  onsubmit="return confirm('Are you sure you want to delete this product?');">
                                @csrf
                                @method('DELETE')
                                <button class="btn btn-sm btn-danger">
                                   <i class="bi bi-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="8" class="text-center text-muted">No products found.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

<!-- jQuery must be loaded first -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<!-- SweetAlert2 JS -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.5.0/dist/sweetalert2.min.js"></script>


<script>
    $(document).ready(function() {
        // AJAX for toggling best product status
        $('.toggle-best-product').on('click', function() {
            var productId = $(this).data('id');
            var button = $(this);

            // Show SweetAlert2 confirmation
            Swal.fire({
                title: 'Are you sure?',
                text: "Do you want to change the Best Product status?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, toggle it!',
                cancelButtonText: 'No, cancel!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: '/admin/products/toggle-best/' + productId,
                        method: 'POST',
                        data: {
                            _token: '{{ csrf_token() }}'
                        },
                        success: function(response) {
                            if (response.status === 'success') {
                                if (response.best_product) {
                                    button.removeClass('btn-secondary').addClass('btn-success');
                                    button.text('Best Product');
                                } else {
                                    button.removeClass('btn-success').addClass('btn-secondary');
                                    button.text('Mark as Best');
                                }

                                // Show success message
                                Swal.fire(
                                    'Success!',
                                    'The Best Product status has been updated.',
                                    'success'
                                );
                            }
                        },
                        error: function() {
                            // Show error message if something goes wrong
                            Swal.fire(
                                'Error!',
                                'There was an error while updating the product status.',
                                'error'
                            );
                        }
                    });
                }
            });
        });
    });
</script>

@endsection